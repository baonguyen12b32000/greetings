<?php

/**
 * @version    CVS: 1.0.0
 * @package    Com_Greetings
 * @author     Ho BAO NGUYEN <baonguyen12b32000@gmail.com>
 * @copyright  2024 Ho BAO NGUYEN
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Comgreetings\Component\Greetings\Site\Service;
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Categories\Categories;
/**
 * Content Component Category Tree
 *
 * @since  1.0.0
 */

