CREATE TABLE IF NOT EXISTS `#__greetings` (
`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,

`state` TINYINT(1)  NULL  DEFAULT 1,
`ordering` INT(11)  NULL  DEFAULT 0,
`checked_out` INT(11)  UNSIGNED,
`checked_out_time` DATETIME NULL  DEFAULT NULL ,
`created_by` INT(11)  NULL  DEFAULT 0,
`modified_by` INT(11)  NULL  DEFAULT 0,
`title` VARCHAR(255)  NOT NULL ,
`message` TEXT NOT NULL ,
PRIMARY KEY (`id`)
,KEY `idx_state` (`state`)
,KEY `idx_checked_out` (`checked_out`)
,KEY `idx_created_by` (`created_by`)
,KEY `idx_modified_by` (`modified_by`)
) DEFAULT COLLATE=utf8mb4_unicode_ci;

INSERT INTO `#__greetings` (`id`, `state`, `ordering`, `checked_out`, `checked_out_time`, `created_by`, `modified_by`, `title`, `message`) VALUES(1, 1, 1, NULL, NULL, 491, 491, 'How’s it going?', 'This is one of those types of greetings that doesn’t always need to be taken literally.');
INSERT INTO `#__greetings` (`id`, `state`, `ordering`, `checked_out`, `checked_out_time`, `created_by`, `modified_by`, `title`, `message`) VALUES(2, 1, 2, NULL, NULL, 491, 491, 'What’s happening?', 'Although a question, this type of greeting can be used in place of “hello!”');
INSERT INTO `#__greetings` (`id`, `state`, `ordering`, `checked_out`, `checked_out_time`, `created_by`, `modified_by`, `title`, `message`) VALUES(3, 1, 3, NULL, NULL, 491, 491, 'It’s nice to meet you', 'Greeting someone. Just don’t say this one to someone you’ve met three times before!');