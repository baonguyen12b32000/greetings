<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_banners
 *
 * @copyright   (C) 2006 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

use Joomla\CMS\Language\Text;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;


?>
<div class="mod_randomgreeting">

<?php foreach ($list as $item) : ?>
	<div class="greeting_item">
		<h4 class="title"><?php echo $item->title; ?></h4>
		<div class="message"><?php echo $item->message; ?></div>
	</div>
<?php endforeach; ?>

</div>
