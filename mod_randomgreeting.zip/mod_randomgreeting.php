<?php

/**
 * @package     Joomla.Site
 * @subpackage  mod_randomgreeting
 *
 * @copyright   (C) 2005 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Helper\ModuleHelper;

use Comgreetings\Component\Greetings\Site\Model\GreetingsModel;
$model = new GreetingsModel();
$list  = $model->getRandomItems(2);

require ModuleHelper::getLayoutPath('mod_randomgreeting', $params->get('layout', 'default'));
